package com.example.remindee

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
